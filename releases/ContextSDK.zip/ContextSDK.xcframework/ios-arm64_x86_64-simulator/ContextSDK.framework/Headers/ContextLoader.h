#ifndef DISABLE_AUTO_START
#import <Foundation/Foundation.h>

@interface ContextLoader : NSObject
@end
#endif
