using System.Collections.Generic;
using System.Runtime.InteropServices;
using AOT;
using UnityEngine;

#nullable enable

public static class ContextSDKBinding
{
    [DllImport("__Internal")]
    private static extern void contextSDK_setupContextManagerWithAPIBackend(string licenseKey);

    [DllImport("__Internal")]
    private static extern bool contextSDK_setGlobalCustomSignalInt(string id, int value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_setGlobalCustomSignalBool(string id, bool value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_setGlobalCustomSignalFloat(string id, float value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_setGlobalCustomSignalString(string id, string value);

    [DllImport("__Internal")]
    private static extern int contextSDK_getNextContextID();

    private static Dictionary<int, ContextDelegate> pendingContextDelegates = new Dictionary<int, ContextDelegate>();
    private delegate void InternalContextDelegate(int contextID);
    public delegate void ContextDelegate(Context context);

    [DllImport("__Internal")]
    private static extern int contextSDK_instantContext(string flowName, int customSignalsID, int duration);
    [DllImport("__Internal")]
    private static extern void contextSDK_calibrate(int contextID, int customSignalsID, string flowName, int maxDelay, InternalContextDelegate callback);
    [DllImport("__Internal")]
    private static extern int contextSDK_recentContext(string flowName);

    [DllImport("__Internal")]
    private static extern bool contextSDK_context_shouldUpsell(int contextID);
    [DllImport("__Internal")]
    private static extern string contextSDK_context_validate(int contextID);

    [DllImport("__Internal")]
    private static extern bool contextSDK_context_log(int contextID, int outcome);
    [DllImport("__Internal")]
    private static extern bool contextSDK_context_logIfNotLoggedYet(int contextID, int outcome);

    [DllImport("__Internal")]
    private static extern bool contextSDK_context_appendOutcomeMetadataInt(int contextID, string id, int value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_context_appendOutcomeMetadataBool(int contextID, string id, bool value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_context_appendOutcomeMetadataFloat(int contextID, string id, float value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_context_appendOutcomeMetadataString(int contextID, string id, string value);

    [DllImport("__Internal")]
    private static extern bool contextSDK_releaseContext(int contextID);

    [DllImport("__Internal")]
    private static extern bool contextSDK_context_addCustomSignalInt(int contextID, string id, int value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_context_addCustomSignalBool(int contextID, string id, bool value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_context_addCustomSignalFloat(int contextID, string id, float value);
    [DllImport("__Internal")]
    private static extern bool contextSDK_context_addCustomSignalString(int contextID, string id, string value);

    [DllImport("__Internal")]
    private static extern bool contextSDK_releaseCustomSignals(int contextID);

    public static void SetupWithAPIBackend(string licenseKey)
    {
#if UNITY_IOS && !UNITY_EDITOR
        contextSDK_setupContextManagerWithAPIBackend(licenseKey);
#endif
    }

    /// <summary>
    ///  Set custom signals that will be used for all ContextSDK events on this instance. We recommend using this to provide generic information that's applicable to all calls, like any AB test information, or other data that may be relevant to calculate the likelihood of an event. Please be sure to not include any PII or other potentially sensitive information. You can overwrite values by using the same id again.
    /// </summary>
    /// <param name="id">The unique id of the custom signal. This id will be used to identify the custom signal in the ContextSDK backend.</param>
    /// <param name="value">The value of the custom signal</param>
    public static void SetGlobalCustomSignal(string id, int value)
    {
#if UNITY_IOS && !UNITY_EDITOR
        contextSDK_setGlobalCustomSignalInt(id, value);
#endif
    }

    /// <summary>
    ///  Set custom signals that will be used for all ContextSDK events on this instance. We recommend using this to provide generic information that's applicable to all calls, like any AB test information, or other data that may be relevant to calculate the likelihood of an event. Please be sure to not include any PII or other potentially sensitive information. You can overwrite values by using the same id again.
    /// </summary>
    /// <param name="id">The unique id of the custom signal. This id will be used to identify the custom signal in the ContextSDK backend.</param>
    /// <param name="value">The value of the custom signal</param>
    public static void SetGlobalCustomSignal(string id, float value)
    {
#if UNITY_IOS && !UNITY_EDITOR
        contextSDK_setGlobalCustomSignalFloat(id, value);
#endif
    }

    /// <summary>
    ///  Set custom signals that will be used for all ContextSDK events on this instance. We recommend using this to provide generic information that's applicable to all calls, like any AB test information, or other data that may be relevant to calculate the likelihood of an event. Please be sure to not include any PII or other potentially sensitive information. You can overwrite values by using the same id again.
    /// </summary>
    /// <param name="id">The unique id of the custom signal. This id will be used to identify the custom signal in the ContextSDK backend.</param>
    /// <param name="value">The value of the custom signal</param>
    public static void SetGlobalCustomSignal(string id, bool value)
    {
#if UNITY_IOS && !UNITY_EDITOR
        contextSDK_setGlobalCustomSignalBool(id, value);
#endif
    }

    /// <summary>
    ///  Set custom signals that will be used for all ContextSDK events on this instance. We recommend using this to provide generic information that's applicable to all calls, like any AB test information, or other data that may be relevant to calculate the likelihood of an event. Please be sure to not include any PII or other potentially sensitive information. You can overwrite values by using the same id again.
    /// </summary>
    /// <param name="id">The unique id of the custom signal. This id will be used to identify the custom signal in the ContextSDK backend.</param>
    /// <param name="value">The value of the custom signal</param>
    public static void SetGlobalCustomSignal(string id, string value)
    {
#if UNITY_IOS && !UNITY_EDITOR
        contextSDK_setGlobalCustomSignalString(id, value);
#endif
    }

    /// <summary>
    /// Get the current context synchronously. The signal may not include all the information, if the duration wasn't reached.
    /// Be sure that the majority of the times when calling this method, the SDK has already had enough time to reach the duration you've set.
    /// </summary>
    public static Context InstantContext(string flowName, CustomSignals? customSignals = null, int duration = 3)
    {

#if UNITY_IOS && !UNITY_EDITOR
        int customSignalsID = customSignals?.contextID ?? -1;
        int contextID = contextSDK_instantContext(flowName, customSignalsID, duration);
        return new Context(contextID);
#else
        return new Context(-1);
#endif
    }

    public static void Calibrate(string flowName, ContextDelegate callback, CustomSignals? customSignals = null, int maxDelay = 3)
    {

#if UNITY_IOS && !UNITY_EDITOR
        int customSignalsID = customSignals?.contextID ?? -1;
        int currentContextID = contextSDK_getNextContextID();
        pendingContextDelegates[currentContextID] = callback;
        contextSDK_calibrate(currentContextID, customSignalsID, flowName, maxDelay, HandleContext);
#else
        // On non iOS always instantly callback.
        callback(new Context(-1));
#endif
    }

    [MonoPInvokeCallback(typeof(InternalContextDelegate))]
    private static void HandleContext(int contextID)
    {
        ContextDelegate callback = pendingContextDelegates[contextID];
        callback.Invoke(new Context(contextID));
        pendingContextDelegates.Remove(contextID);
    }

    /// <summary>
    /// Fetch the most recently generated Context for a given flowName
    /// </summary>
    public static Context? RecentContext(string flowName)
    {
#if UNITY_IOS && !UNITY_EDITOR
        int contextID = contextSDK_recentContext(flowName);
        if (contextID == -1)
        {
            return null;
        }

        return new Context(contextID);
#else
        return null;
#endif
    }

    public class CustomSignals
    {
        internal int contextID;
        public CustomSignals()
        {
#if UNITY_IOS && !UNITY_EDITOR
            this.contextID = contextSDK_getNextContextID();
#else
            this.contextID = -1;
#endif
        }

        public void AppendCustomSignal(string id, int value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_addCustomSignalInt(contextID, id, value);
#endif
        }

        public void AppendCustomSignal(string id, float value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_addCustomSignalFloat(contextID, id, value);
#endif
        }

        public void AppendCustomSignal(string id, bool value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_addCustomSignalBool(contextID, id, value);
#endif
        }

        public void AppendCustomSignal(string id, string value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_addCustomSignalString(contextID, id, value);
#endif
        }

        ~CustomSignals()
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_releaseCustomSignals(contextID);
#endif
        }
    }

    public class Context
    {
        internal int contextID;
        /// <summary>
        /// Check if you now is a good time to show an upsell prompt. During calibration phase, this will always be `true`.
        /// </summary>
        public readonly bool shouldUpsell = true;
        internal Context(int contextID)
        {
            this.contextID = contextID;
#if UNITY_IOS && !UNITY_EDITOR
            this.shouldUpsell = contextSDK_context_shouldUpsell(contextID);
#endif
        }

        /// <summary>
        ///  Use this method to log an outcome and send the context event to the backend
        /// </summary>
        public void Log(Outcome outcome)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_log(contextID, ((int)outcome));
#endif
        }

        /// <summary>
        /// Use this function to log an outcome only if this particular context object hasn't been logged yet
        /// </summary>
        public void LogIfNotLoggedYet(Outcome outcome)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_logIfNotLoggedYet(contextID, ((int)outcome));
#endif
        }

        /// <summary>
        /// This method allows you to append custom outcomes to that specific outcome
        /// We recommend using this method to provide information like the selected price tier / plan, or other relevant info about the type of product or action the user has selected
        /// </summary>
        public void AppendOutcomeMetadata(string id, int value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_appendOutcomeMetadataInt(contextID, id, value);
#endif
        }

        /// <summary>
        /// This method allows you to append custom outcomes to that specific outcome
        /// We recommend using this method to provide information like the selected price tier / plan, or other relevant info about the type of product or action the user has selected
        /// </summary>
        public void AppendOutcomeMetadata(string id, bool value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_appendOutcomeMetadataBool(contextID, id, value);
#endif
        }

        /// <summary>
        /// This method allows you to append custom outcomes to that specific outcome
        /// We recommend using this method to provide information like the selected price tier / plan, or other relevant info about the type of product or action the user has selected
        /// </summary>
        public void AppendOutcomeMetadata(string id, float value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_appendOutcomeMetadataFloat(contextID, id, value);
#endif
        }

        /// <summary>
        /// This method allows you to append custom outcomes to that specific outcome
        /// We recommend using this method to provide information like the selected price tier / plan, or other relevant info about the type of product or action the user has selected
        /// </summary>
        public void AppendOutcomeMetadata(string id, string value)
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_context_appendOutcomeMetadataString(contextID, id, value);
#endif
        }

        /// <summary>
        /// Call this method to do a local validation of your ContextSDK setup
        /// </summary>
        /// <returns>A string with diagnostic information.</returns>
        public string Validate()
        {
#if UNITY_IOS && !UNITY_EDITOR
            return contextSDK_context_validate(contextID);
#else
            return "Calling Validate from outside of iOS is not supported.";
#endif
        }

        ~Context()
        {
#if UNITY_IOS && !UNITY_EDITOR
            contextSDK_releaseContext(contextID);
#endif
        }
    }

    /// <summary>
    /// Describes the outcome of a flow.
    /// </summary>
    public enum Outcome
    {
        /// <summary>
        /// Optional outcome: The user has tapped on the ad, and followed any external link provided.
        /// </summary>

        PositiveAdTapped = 4,

        /// <summary>
        /// Optional outcome: The user ended up successfully purchasing the product (all the way through the payment flow)
        /// </summary>    
        PositiveConverted = 3,

        /// <summary>
        ///  Optional outcome: The user has tapped on the banner, and started the purchase flow, or read more about the offer
        /// </summary>
        PositiveInteracted = 2,

        /// <summary>
        ///  A generic, positive signal. Use this for the basic ContextSDK integration, e.g. when showing an upsell prompt.
        /// </summary>
        Positive = 1,

        /// <summary>
        /// Log this when ContextSDK has recommended to skip showing an upsell prompt (`.shouldUpsell` is false). Logging this explicitly is not required if you use `ContextSDKBinding.Calibrate()` as it will be handled by ContextSDK automatically.
        /// </summary>
        Skipped = 0,

        /// <summary>
        ///  A generic, negative signal. Use this for the basic ContextSDK integration, on a user e.g. declining or dismissing an upsell prompt
        /// </summary>
        Negative = -1,

        /// <summary>
        ///  Optional outcome: Use this as a negative signal of a user not interacting with e.g. a banner. Depending on your app, we may recommend to log this when the app is put into the background, and hasn't interacted with a banner in any way. This can be done using the `LogIfNotLoggedYet` method
        /// </summary>
        NegativeNotInteracted = -2,

        /// <summary>
        /// Optional outcome: The user has actively dismissed the banner (e.g. using a close button)
        /// </summary>
        NegativeDismissed = -3
    }
}
