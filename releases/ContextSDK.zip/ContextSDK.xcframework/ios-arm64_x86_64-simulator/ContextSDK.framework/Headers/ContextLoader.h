#import <Foundation/Foundation.h>

@interface ContextLoader : NSObject
@end
